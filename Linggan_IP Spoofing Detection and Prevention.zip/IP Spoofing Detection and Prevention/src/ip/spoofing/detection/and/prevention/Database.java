package ip.spoofing.detection.and.prevention;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import org.postgresql.jdbc.PgConnection;
import org.postgresql.largeobject.LargeObject;
import org.postgresql.largeobject.LargeObjectManager;

public class Database
{
    private static PgConnection connection = null;

    private final static String url = "jdbc:postgresql://localhost:5432/IP Spoofing?user=postgres&password=postgres";

    public static void InitDatabase()
    {
        try
        {
            Class.forName ( "org.postgresql.Driver" );
        }
        catch ( final ClassNotFoundException e )
        {
            e.printStackTrace();
        }
    }
    
    public static void OpenDatabase() throws SQLException
    {
        CloseDatabase();

        DriverManager.setLoginTimeout ( 100 );
        connection = ( PgConnection ) DriverManager.getConnection ( url );
        
        connection.setAutoCommit ( false );
    }

    public static PreparedStatement GetPreparedStatement ( final String sql ) throws SQLException
    {
        return connection.prepareStatement ( sql );
    }

    public static long NonQueryDatabase ( final PreparedStatement ps ) throws SQLException
    {
        long newID = -1;
        
        ResultSet rs = null;
        
        SQLException sqlException = null;

        try
        {
            rs = ps.executeQuery();

            rs.next();
            
            newID = rs.getLong ( 1 );
        }
        catch ( final SQLException e )
        {
            sqlException = e;
        }
        finally
        {
            try
            {
                if ( rs != null ) rs.close();
            }
            catch ( final SQLException e )
            {}

            try
            {
                if ( ps != null ) ps.close();
            }
            catch ( final SQLException e )
            {}
        }

        if ( sqlException != null )
            throw sqlException;

        return newID;
    }
    
    public static void Commit() throws SQLException
    {
        connection.commit();
    }

    public static void UnlinkLargeObject ( final long oid ) throws SQLException, IOException
    {
        final LargeObjectManager lobj = connection.getLargeObjectAPI();

        lobj.unlink ( oid );
    }
    
    public static long WriteLargeObject ( final InputStream inputStream ) throws SQLException, IOException
    {
        final LargeObjectManager lobj = connection.getLargeObjectAPI();

        final long oid = lobj.createLO ( LargeObjectManager.READ | LargeObjectManager.WRITE );

        final LargeObject obj = lobj.open(oid, LargeObjectManager.WRITE);
        
        final byte buf[] = new byte [ 2048 ];
        int data;

        while ( ( data = inputStream.read ( buf, 0, 2048 ) ) > 0 )
            obj.write(buf, 0, data);
        
        obj.close();
        
        return oid;
    }
    
    public static BufferedImage LoadImage ( final long oid ) throws SQLException, IOException
    {
        final LargeObjectManager lobj = connection.getLargeObjectAPI();

        final LargeObject objPicture = lobj.open ( oid, LargeObjectManager.READ );
        
        final byte[] bufPicture = new byte[objPicture.size()];
        objPicture.read ( bufPicture, 0, objPicture.size() );
        objPicture.close();
        
        final BufferedImage bImage = ImageIO.read ( new ByteArrayInputStream ( bufPicture ) );

        return bImage;
    }
    
    public static void CloseDatabase() throws SQLException
    {
        if ( connection != null )
        {
            connection.close();
            connection = null;
        }
    }    
}
