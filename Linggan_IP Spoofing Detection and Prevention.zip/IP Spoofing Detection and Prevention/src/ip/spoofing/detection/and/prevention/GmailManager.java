package ip.spoofing.detection.and.prevention;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class GmailManager
{
    private final static String subject = "Potential Spoof Attempt Detected!";
    private final static SimpleDateFormat sdf = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss" );

    public static void SendReport ( final String receipient ) throws AddressException, MessagingException
    {
        final String dateTime = sdf.format ( new Date() );
        final String message = "Greetings,<br /><br />A potential spoofing attempt was detected at " + dateTime + "!<br /><br />Best regards,<br />IP Spoofing Detection and Prevention System";

        SendEmail ( receipient, subject, message );
    }

    public static void SendReport ( final String[] receipients ) throws AddressException, MessagingException
    {
        final String dateTime = sdf.format ( new Date() );
        final String message = "Greetings,<br /><br />A potential spoofing attempt was detected at " + dateTime + "!<br /><br />Best regards,<br />IP Spoofing Detection and Prevention System";

        SendEmail ( receipients, subject, message );
    }

    public static void SendEmail ( final String receipient, final String subject, final String message ) throws AddressException, MessagingException
    {
        SendEmail ( new String[] { receipient }, subject, message );
    }

    public static void SendEmail ( final String[] receipients, final String subject, final String message ) throws AddressException, MessagingException
    {
        final String host = "smtp.gmail.com";
 
        final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

        final String from = "ip.spoofing.detection@gmail.com";
        final String password = "ip.spoofing.detection2021";

        final boolean sessionDebug = false;

        final Properties props = System.getProperties(); 

        props.put ( "mail.host", host );
        props.put ( "mail.transport.protocol.", "smtp" );
        props.put ( "mail.smtp.auth", "true" );
        props.put ( "mail.smtp.", "true" );
        props.put ( "mail.smtp.port", "465" );
        props.put ( "mail.smtp.socketFactory.fallback", "false" );
        props.put ( "mail.smtp.socketFactory.class", SSL_FACTORY );
        props.put ( "mail.smtp.ssl.trust", "*" );

        final Session mailSession = Session.getDefaultInstance ( props, null );
        mailSession.setDebug ( sessionDebug );

        final Message msg = new MimeMessage ( mailSession ); 
        msg.setFrom ( new InternetAddress ( from ) );

        final ArrayList<InternetAddress> alReceipients = new ArrayList<>();

        for ( final String receipient : receipients )
            alReceipients.add ( new InternetAddress ( receipient ) );

        final InternetAddress[] address = alReceipients.toArray ( new InternetAddress [ alReceipients.size() ] );

        msg.setRecipients ( Message.RecipientType.TO, address );
        msg.setSubject ( subject );
        msg.setContent ( message, "text/html" ); // use setText if you want to send text

        final Transport transport = mailSession.getTransport ( "smtp" );
        System.setProperty ( "javax.net.ssl.trustStore", "conf/jssecacerts" );
        System.setProperty ( "javax.net.ssl.trustStorePassword", "changeit" );
        transport.connect ( host, from, password );

        transport.sendMessage ( msg, msg.getAllRecipients() );

        transport.close();
    }
}
