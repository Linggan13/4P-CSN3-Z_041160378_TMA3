package ip.spoofing.detection.and.prevention;

import javax.swing.JFrame;

public class IPSpoofingDetectionAndPrevention
{
    public static void main ( final String[] args )
    {
        // TODO code application logic here
        LoginFrame.setDefaultLookAndFeelDecorated ( true );
        final LoginFrame frame = new LoginFrame();
        frame.setTitle ( "IP Spoofing Detection and Prevention (Login Page)" );
        frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
        frame.setVisible ( true );
    }
}
