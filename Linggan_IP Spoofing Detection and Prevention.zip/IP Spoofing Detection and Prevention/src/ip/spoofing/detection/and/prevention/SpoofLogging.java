package ip.spoofing.detection.and.prevention;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SpoofLogging
{
    public static boolean SaveReport ( final String prevMACAddress, final String currMACAddress, final String currIPAddress )
    {
        final String sql = "INSERT INTO \"Detected Spoofing Logs\" (\"Timestamp Detected\",\"Previous MAC Address\",\"Current MAC Address\",\"Current IP Address\",\"Username\")" +
            " VALUES (NOW(),?,?,?,?)";

        try ( final PreparedStatement ps = Database.GetPreparedStatement ( sql ) )
        {
            ps.setString ( 1, prevMACAddress );
            ps.setString ( 2, currMACAddress );
            ps.setString ( 3, currIPAddress );
            ps.setString ( 4, UserProfile.username );

            ps.executeUpdate();
            Database.Commit();

            return true;
        }
        catch ( final SQLException e )
        {
            return false;
        }
   }
}
