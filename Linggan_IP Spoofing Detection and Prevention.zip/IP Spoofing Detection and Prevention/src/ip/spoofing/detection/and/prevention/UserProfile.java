package ip.spoofing.detection.and.prevention;

public class UserProfile
{
    public static String username = "";
    public static String email = "";
}
